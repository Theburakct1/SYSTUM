from SYSTUM import app
from motor.motor_asyncio import AsyncIOMotorClient
from pyrogram import filters
from pyrogram.types import ChatPrivileges
import os
import ssl
from pydub import AudioSegment
import speech_recognition as sr

# SSL configuration
ssl._create_default_https_context = ssl._create_unverified_context

# MongoDB setup
MONGO_URL = "mongodb+srv://genshinimpect15:burak383812@cluster0.annww.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0&ssl=true"
mongo_client = AsyncIOMotorClient(MONGO_URL)
db = mongo_client.systum
stt_collection = db.stt_settings

# Temporary folder setup
TEMP_FOLDER = "temp"
os.makedirs(TEMP_FOLDER, exist_ok=True)

async def is_stt_enabled(chat_id: int) -> bool:
    """Check if STT is enabled for the chat"""
    settings = await stt_collection.find_one({'chat_id': chat_id})
    return settings['enabled'] if settings else True  # Default is enabled

async def can_change_info(client, message) -> bool:
    """Check if user has can_change_info privilege"""
    if message.chat.type in ["private", "bot"]:
        return True
        
    user = await message.chat.get_member(message.from_user.id)
    return user.privileges and user.privileges.can_change_info

@app.on_message(filters.command("stt"))
async def stt_settings(client, message):
    # Yetki kontrolü
    if not await can_change_info(client, message):
        await message.reply("❌ Bu komutu sadece grup bilgilerini değiştirebilen yöneticiler kullanabilir.")
        return

    chat_id = message.chat.id
    args = message.text.split()
    
    if len(args) != 2 or args[1] not in ['on', 'off']:
        await message.reply("❌ Kullanım: /stt on veya /stt off")
        return
        
    enabled = args[1] == 'on'
    await stt_collection.update_one(
        {'chat_id': chat_id},
        {'$set': {'enabled': enabled}},
        upsert=True
    )
    
    status = "açık" if enabled else "kapalı"
    await message.reply(f"✅ Ses tanıma sistemi {status} duruma getirildi.")

@app.on_message(filters.voice)
async def handle_voice(client, message):
    if not await is_stt_enabled(message.chat.id):
        return

    try:
        # Download voice message
        file_path = await message.download(
            file_name=f"{TEMP_FOLDER}/{message.voice.file_id}.ogg"
        )
        
        # Convert OGG to WAV
        audio = AudioSegment.from_ogg(file_path)
        wav_path = file_path.replace('.ogg', '.wav')
        audio.export(wav_path, format="wav")

        # Convert to text using Google Speech Recognition
        recognizer = sr.Recognizer()
        with sr.AudioFile(wav_path) as source:
            audio_data = recognizer.record(source)
            try:
                text = recognizer.recognize_google(audio_data, language='tr-TR')
                await message.reply(text)
            except sr.UnknownValueError:
                pass  # Silently ignore unrecognizable audio
            except sr.RequestError:
                pass  # Silently ignore service errors

    except Exception as e:
        print(f"Error in STT: {str(e)}")
    finally:
        # Cleanup temporary files
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
            if os.path.exists(wav_path):
                os.remove(wav_path)
        except Exception:
            pass