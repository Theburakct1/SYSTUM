from pyrogram import filters
import requests
from SYSTUM import app

# API anahtarınızı ve host bilgisini buraya ekleyin
api_key = "9b07a022a7msh81fc23061b520f6p1c6ae1jsncb9b960c5a6f"
api_host = "youtube-mp3-downloader1.p.rapidapi.com"  # YouTube MP3 Downloader API hostu

@app.on_message(filters.command(["ytmp3", "youtube", "mp3"]))
async def download_youtube_mp3(client, message):
    if len(message.command) < 2:
        await message.reply_text("Lütfen komuttan sonra YouTube video URL'sini sağlayın.")
        return

    a = await message.reply_text("MP3'ü indiriyorum...")

    # Kullanıcının sağladığı URL
    url = message.text.split()[1]

    # RapidAPI URL'si
    api_url = f"https://{api_host}/download?url={url}"

    # RapidAPI header bilgileri
    headers = {
        "x-rapidapi-key": api_key,
        "x-rapidapi-host": api_host
    }

    try:
        # API'ye istek gönder
        response = requests.get(api_url, headers=headers)
        response.raise_for_status()  # Hata varsa yakalar
        data = response.json()

        # API cevabını kontrol et
        if "mp3" in data and data["mp3"]:
            mp3_url = data["mp3"]  # MP3 dosyasının URL'sini al
            await a.delete()
            await client.send_audio(message.chat.id, mp3_url)  # MP3 dosyasını gönder
        else:
            await a.edit("MP3 indirme işlemi başarısız oldu. Lütfen URL'yi kontrol edin.")
    except Exception as e:
        await a.edit(f"Hata oluştu: {str(e)}")


@app.on_message(filters.command(["search"]))
async def search_youtube_video(client, message):
    if len(message.command) < 2:
        await message.reply_text("Lütfen aramak istediğiniz YouTube video başlığını veya URL'sini yazın.")
        return

    query = message.text.split()[1]

    # API araması için URL oluşturma
    api_url = f"https://{api_host}/search?query={query}"

    headers = {
        "x-rapidapi-key": api_key,
        "x-rapidapi-host": api_host
    }

    try:
        # API'ye istek gönder
        response = requests.get(api_url, headers=headers)
        response.raise_for_status()  # Hata varsa yakalar
        data = response.json()

        if "mp3" in data and data["mp3"]:
            mp3_url = data["mp3"]
            await client.send_audio(message.chat.id, mp3_url)
        else:
            await message.reply_text("Aradığınız video bulunamadı.")
    except Exception as e:
        await message.reply_text(f"Hata oluştu: {str(e)}")
