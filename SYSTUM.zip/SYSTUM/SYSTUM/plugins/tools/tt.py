import requests
from pyrogram import filters
from SYSTUM import app
import re

@app.on_message(filters.regex(r"(http|https)://.*tiktok.*"))
async def download_tiktok_video(client, message):
    # Mesajdaki URL'yi regex ile çek
    url_match = re.search(r"(http|https)://.*tiktok.*", message.text)
    
    if not url_match:
        return  # Eğer geçerli bir URL yoksa, hiçbir işlem yapmıyoruz.

    url = url_match.group(0)  # URL'yi al

    a = await message.reply_text("Videoyu indiriliyor...")

    # API URL ve başlık bilgileri
    api_url = f"https://tiktok-download-video-no-watermark.p.rapidapi.com/tiktok/info"
    headers = {
        "x-rapidapi-key": "33d4cf5a85msh76a95cc855f2a30p1ec9acjsnae5c0455b287",  # Kendi API anahtarınızı ekleyin
        "x-rapidapi-host": "tiktok-download-video-no-watermark.p.rapidapi.com"
    }

    try:
        # API'den veri çek
        response = requests.get(api_url, headers=headers, params={"url": url})
        response.raise_for_status()
        data = response.json()

        # Video URL'si varsa işle
        if 'data' in data and 'video_link_nwm' in data['data']:
            video_url = data['data']['video_link_nwm']  # Watermark'sız video linki
            await a.delete()
            await client.send_video(
                chat_id=message.chat.id,
                video=video_url,
                caption="@beplormusic"
            )
        else:
            await a.edit("TikTok videosu indirilemedi. Lütfen URL'yi kontrol edin.")
    except Exception as e:
        await a.edit(f"Hata oluştu: {str(e)}")

__MODULE__ = "TikTok"
__HELP__ = """/tiktok [TikTok video URL] - TikTok videosu indirir
"""
