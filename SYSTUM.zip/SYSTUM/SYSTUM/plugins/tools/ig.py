import requests
from pyrogram import filters
from SYSTUM import app
import re

@app.on_message(filters.regex(r"(http|https)://.*instagram.*"))
async def download_instagram_video(client, message):
    # Mesajdaki URL'yi regex ile çek
    url_match = re.search(r"(http|https)://.*instagram.*", message.text)
    
    if not url_match:
        return  # Eğer geçerli bir URL yoksa, hiçbir işlem yapmıyoruz.

    url = url_match.group(0)  # URL'yi al

    a = await message.reply_text("Videoyu indiriyor...")

    # API URL ve başlık bilgileri
    api_url = f"https://instagram-downloader-download-instagram-videos-stories1.p.rapidapi.com/get-info-rapidapi?url={url}"
    headers = {
        "x-rapidapi-key": "4661bf4f8amshc407730f2730ae3p1cdf30jsn4bafaebd75aa",  # Kendi API anahtarınızı ekleyin
        "x-rapidapi-host": "instagram-downloader-download-instagram-videos-stories1.p.rapidapi.com"
    }

    try:
        # API'den veri çek
        response = requests.get(api_url, headers=headers)
        response.raise_for_status()
        data = response.json()

        # Medya URL'si varsa işle
        if not data.get("error") and "download_url" in data:
            video_url = data["download_url"]  # Videonun indirilebilir bağlantısı
            await a.delete()
            await client.send_video(
                chat_id=message.chat.id,
                video=video_url,
                caption="@beplormusic"
            )
        else:
            await a.edit("Reel indirilemedi. Lütfen URL'yi kontrol edin.")
    except Exception as e:
        await a.edit(f"Hata oluştu: {str(e)}")

__MODULE__ = "Instagram"
__HELP__ = """/reel [Instagram reel URL] - Reel indirir
/ig [Instagram reel URL] - Reel indirir
/instagram [Instagram reel URL] - Reel indirir
"""
