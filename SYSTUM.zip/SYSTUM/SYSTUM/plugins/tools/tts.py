import io
from gtts import gTTS
from pyrogram import filters
from SYSTUM import app

@app.on_message(filters.command("tts"))
async def text_to_speech(client, message):
    if len(message.command) < 2:
        return await message.reply_text(
            "Lütfen sese dönüştürmek için bir metin sağlayın."
        )

    text = message.text.split(None, 1)[1]
    tts = gTTS(text, lang="tr")  # Dil Türkçe olarak ayarlandı
    audio_data = io.BytesIO()
    tts.write_to_fp(audio_data)
    audio_data.seek(0)

    audio_file = io.BytesIO(audio_data.read())
    audio_file.name = "ses.mp3"
    await message.reply_audio(audio_file)


__HELP__ = """
**Metni Sese Dönüştürme Botu Komutları**

Metni sese dönüştürmek için `/tts` komutunu kullanın.

- `/tts <metin>`: Verilen metni Türkçe olarak sese dönüştürür.

**Örnek:**
- `/tts Merhaba Dünya`

**Not:**
`/tts` komutundan sonra bir metin yazdığınızdan emin olun.
"""

__MODULE__ = "MetniSese"
