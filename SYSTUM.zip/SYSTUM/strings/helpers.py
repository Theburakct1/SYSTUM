HELP_1 = """
<b><u>Yönetici Komutları:</b></u>

Komutların başına <b>C</b> ekleyerek kanal için kullanabilirsiniz.

- /pause: Şu anki çalan yayını duraklatır.
- /resume: Duraklatılan yayını devam ettirir.
- /skip: Şu anki çalan yayını atlar ve sıradaki şarkıyı çalmaya başlar.
- /end veya /stop: Kuyruğu temizler ve şu anki yayını sonlandırır.
- /player: Etkileşimli bir medya oynatıcı paneli gösterir.
- /queue: Kuyrukta bulunan şarkı listesini gösterir.
"""

HELP_2 = """
<b><u>Yetkili Kullanıcılar:</b></u>

Yetkili kullanıcılar, sohbetlerde yönetici haklarına sahip olmasalar da botun yönetici haklarını kullanabilirler.

- /auth [kullanıcı_adı/kullanıcı_id]: Bir kullanıcıyı botun yetkili listesine ekler.
- /unauth [kullanıcı_adı/kullanıcı_id]: Bir kullanıcıyı yetkili kullanıcı listesinden çıkarır.
- /authusers: Grup içindeki yetkili kullanıcıların listesini gösterir.
"""

HELP_3 = """
<u><b>Yayın Özelliği</b></u> [sadece sudo kullanıcıları için]:

- /broadcast [mesaj veya mesaja yanıt]: Botun hizmet verdiği sohbetlere mesaj yayınlar.

<u>Yayın Modları:</u>
- <b>-pin</b>: Yayınlanan mesajları sohbetlerde sabitler.
- <b>-pinloud</b>: Yayınlanan mesajları sohbetlerde sabitler ve üyelerine bildirim gönderir.
- <b>-user</b>: Mesajı botu başlatan kullanıcılara gönderir.
- <b>-assistant</b>: Mesajı botun asistan hesabından gönderir.
- <b>-nobot</b>: Botun mesajı yayınlamasını engeller.

<b>Örnek:</b> <code>/broadcast -user -assistant -pin Yayın testi</code>
"""

HELP_4 = """
<u><b>Soğuk Sohbet Kara Liste Özelliği:</b></u> [sadece sudo kullanıcıları için]

Botumuzu kötü sohbetlere karşı korur.

- /blacklistchat [sohbet_id]: Bir sohbeti kara listeye ekler.
- /whitelistchat [beyaz liste] : whitelistchat'i takip edin.
- /blacklistedchat : kara liste sohbeti izleyenler için.
"""

HELP_5 = """
<b><u>Kara Liste Durum:</b></u>

- /blackliststatus: Kara listeye eklenmiş sohbetlerin durumunu gösterir.
"""

HELP_6 = """
<b><u>Bot Kapatma ve Başlatma:</b></u> [sadece sudo kullanıcıları için]

- /stopbot: Botu kapatır ve başlatılana kadar çalışmaz.
- /startbot: Botu tekrar başlatır.
"""

HELP_7 = """
<b><u>Özel Komutlar:</b></u>

- /clear: Kuyrukta bulunan tüm şarkıları temizler.
- /setlang [dil]: Botun dilini değiştirir. Desteklenen diller: en, tr, de, fr, es.
- /setprefix [önek]: Bot komutları için yeni bir önek belirler.
- /info: Bot hakkında genel bilgi verir.
"""

HELP_8 = """
<b><u>Yayıncı Komutları:</b></u> [sadece yayıncılar için]

- /setstream [link]: Yayıncı, botun dinlediği yayın linkini değiştirir.
- /streamstatus: Yayın durumunu kontrol eder.
- /setquality [kalite]: Yayın kalitesini ayarlamak için kullanılır.
"""

HELP_9 = """
<b><u>Kanal Özellikleri:</b></u>

- /addchannel [kanal_id]: Bir kanal ekler ve botun orada çalışmasını sağlar.
- /removechannel [kanal_id]: Bir kanalı botun çalışma listesinden çıkarır.
"""

HELP_10 = """
<b><u>Bot Hakkında:</b></u>

- /about: Botun genel özelliklerini gösterir.
- /credits: Botu geliştiren kişilerin bilgilerini gösterir.
"""

HELP_11 = """
<u><b>ᴩʟᴀʏ ᴄᴏᴍᴍᴀɴᴅs :</b></u>

<b>v :</b> vɪᴅᴇᴏ ᴩʟᴀʏ'ı temsil eder.
<b>force :</b> fᴏʀᴄᴇ ᴩʟᴀʏ'ı temsil eder.

/play ᴏʀ /vplay : ɪstᴇnɪlᴇɴ şarkıyı vɪᴅᴇᴏᴄʜᴀᴛ üzerinde yayına başlatır.

/playforce ᴏʀ /vplayforce : ᴏɴɢᴏɪɴɢ yayını durdurur ve istenilen şarkıyı yayına başlatır.
"""

HELP_12 = """
<b><u>sʜᴜғғʟᴇ ᴏ̨ᴜᴇᴜᴇ :</b></u>

/shuffle : kuyrukta bulunan şarkıları karıştırır.
/queue : karıştırılmış kuyrukta bulunan şarkıları gösterir.
"""

HELP_13 = """
<b><u>sᴇᴇᴋ sᴛʀᴇᴀᴍ :</b></u>

/seek [süresi saniye cinsinden] : yayını belirtilen süreye göre ileriye sarar.
/seekback [süresi saniye cinsinden] : yayını belirtilen süre kadar geri sarar.
"""

HELP_14 = """
<b><u>sᴏɴɢ ᴅᴏᴡɴʟᴏᴀᴅ</b></u>

/song [şarkı adı/youtube URL] : YouTube'dan istediğiniz şarkıyı MP3 veya MP4 formatında indirir.
"""

HELP_15 = """
<b><u>sᴘᴇᴇᴅ ᴄᴏᴍᴍᴀɴᴅs :</b></u>

Şu anki yayının ses hızını kontrol edebilirsiniz. [Yöneticiler için geçerli]

/speed veya /playback : Grup içinde ses oynatma hızını ayarlamak için kullanılır.
/cspeed veya /cplayback : Kanalda ses oynatma hızını ayarlamak için kullanılır.
"""
